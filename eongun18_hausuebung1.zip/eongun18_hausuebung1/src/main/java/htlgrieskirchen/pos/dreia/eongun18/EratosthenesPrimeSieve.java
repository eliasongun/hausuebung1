/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package htlgrieskirchen.pos.dreia.eongun18;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author eongu
 */
public class EratosthenesPrimeSieve implements PrimeSieve {

    int obergrenze;

    public EratosthenesPrimeSieve(int obergrenze) {

        this.obergrenze = obergrenze;

    }

    @Override
    public boolean isPrime(int p) {
        boolean isprim;
        for (int i = 2; i < p; i++) {
            if (p % i == 0) {
                isprim = false;
                //  System.out.println(p +" NEIN");
                return isprim; // Zahl ist teilbar, also nicht prim
            }
        }
        isprim = true;
        //   System.out.println(p + " JA");
        return isprim; // Zahl ist jetzt Primzahl
    }

    @Override
    public void printPrimes() {

        boolean prim;
        int limit;
        int zaehler;
        int zahl;

        Scanner s = new Scanner(System.in);
        limit = s.nextInt();
        if (limit < 2) {
            System.out.println("Ab 2 ist alles erlaubt !");
            System.exit(0);
        }

        for (zahl = 2; zahl <= limit; zahl++) {

            prim = true;

            for (zaehler = 2; zaehler <= zahl / 2; zaehler++) {
                if (zahl % zaehler == 0) {

                    prim = false;
                    break;
                }

            }

            if (prim) {

                System.out.println(zahl + " ist Prim");
            }
        }
        s.close();

    }

    

    @Override
    public void addierePrimes() {

        int prim1;
        int prim2;

        List<Integer> list = new ArrayList<>();

        for (int i = 2; i < obergrenze; i++) {

            if (i > 2 && (i % 2 == 0)) {

                list.add(i);

            }

        }

        for (int i = 0; i < list.size(); i++) {
            
            prim1 = i+2;
            prim2=i+2;

            if (isPrime(prim1) && isPrime(prim2)) {

                if(list.get(i)== prim1 + prim2)
                {
                System.out.println(list.get(i) + " summe:" + list.get(i) + " = " + prim1 + "+" + prim2);
                }
            }

        }

    }

}
