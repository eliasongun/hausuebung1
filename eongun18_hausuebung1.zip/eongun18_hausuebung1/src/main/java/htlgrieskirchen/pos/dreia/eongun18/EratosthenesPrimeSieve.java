/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package htlgrieskirchen.pos.dreia.eongun18;

import java.util.Scanner;

/**
 *
 * @author eongu
 */
public class EratosthenesPrimeSieve implements PrimeSieve {

   

    

   
 
    @Override
    public boolean isPrime(int p) {
        boolean isprim;
        for (int i = 2; i < p; i++) {
            if (p % i == 0) {
                isprim = false;
                System.out.println("Keine Primzahl");
                return isprim; // Zahl ist teilbar, also nicht prim
            }
        }
        isprim = true;
        System.out.println("Primzahl");
        return isprim; // Zahl ist jetzt Primzahl
    }

    @Override
    public void printPrimes() {
       
        
        boolean prim;
        int limit;
        int zaehler;
        int zahl;
         
 
        Scanner s = new Scanner(System.in);
        limit = s.nextInt();
        if (limit < 2) {
            System.out.println("Ab 2 ist alles erlaubt !");
            System.exit(0);
        }
 
        for (zahl = 2; zahl <= limit; zahl++) {
 
            prim = true;
 
            for (zaehler = 2; zaehler <= zahl / 2; zaehler++) {
                if (zahl % zaehler == 0) {
 
                    prim = false;
                    break;
                }
 
            }
 
            if (prim) {
 
                System.out.println(zahl + " ist Prim");
            }
        }
        s.close();

    }
    
    public void primzahlenAddieren(int max){
        
        boolean prim;
        int limit;
        int zaehler;
        int zahl;
         
 
        Scanner s = new Scanner(System.in);
        limit = s.nextInt();
        if (limit < 2) {
            System.out.println("Ab 2 ist alles erlaubt !");
            System.exit(0);
        }
 
        for (zahl = 2; zahl <= limit; zahl++) {
 
            prim = true;
 
            for (zaehler = 2; zaehler <= zahl / 2; zaehler++) {
                if (zahl % zaehler == 0) {
 
                    prim = false;
                    break;
                }
 
            }
 
            if (prim) {
 
                System.out.println(zahl + " ist Prim");
            }
        }
        s.close();

    }
}
